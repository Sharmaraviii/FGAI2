# GitHub upload checklist

- [ ] Upload README.md, requirements.txt, src/, and notebooks/.
- [ ] Upload artifacts/ including metrics, plots, temperature analysis, and translation samples.
- [ ] Replace illustrative evaluation artifacts with outputs from a successful experiment before making empirical claims.
- [ ] Do not upload Hugging Face access tokens, credentials, or private files.
- [ ] Include the OPUS Books dataset source link in README.
- [ ] Confirm the repository is accessible to the evaluator.
- [ ] The assignment's LMS PDF is submission/Ravi_Sharma_230953324_FGAI_Assignment3.pdf.
- [ ] Include the assignment report PDF/DOCX from the submission folder.
