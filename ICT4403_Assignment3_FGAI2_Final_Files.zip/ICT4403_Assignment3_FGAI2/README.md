# ICT4403 Assignment 3 — English-to-French Machine Translation

**Student:** Ravi Sharma  
**Registration:** 230953324  
**GitHub repository:** https://github.com/Sharmaraviii/FGAI22

> **Evaluation note:** The numeric values in `artifacts/metrics.csv`, temperature CSVs, charts, and sample translations are illustrative simulated examples. They were not measured by executing the four models. They demonstrate the evaluation workflow and should not be interpreted as empirical findings. Run the experiment to generate measured results.

## 1. Objective
Compare four translation systems required by the assignment:
1. Basic PyTorch encoder–decoder Transformer trained from scratch.
2. `google/mt5-small` encoder–decoder fine-tuned on parallel text.
3. `meta-llama/Llama-3.2-1B-Instruct` decoder-only model prompted for translation.
4. `google/gemma-3-1b-it` decoder-only model prompted for translation.

Evaluate BLEU, chrF, task training/fine-tuning time, inference time, parameter count, and sampling-temperature behavior. Discuss architecture, model size, pretraining, tokenization, adaptation, and responsible-AI risks.

## 2. Dataset
- **Dataset:** OPUS Books, English–French (`en-fr`).
- **Hugging Face source:** https://huggingface.co/datasets/Helsinki-NLP/opus_books
- **Corpus:** https://opus.nlpl.eu/Books
- **Configured subset:** up to 1,000 aligned pairs.
- **Split:** 80% train (800), 10% validation (100), 10% test (100), seed 42.
- Preprocessing: remove empty pairs, trim whitespace, filter unusually long pairs, deterministic shuffle, tokenize and truncate/pad.

The code downloads the public dataset and creates `artifacts/train.csv`, `artifacts/validation.csv`, and `artifacts/test.csv` when executed. This package includes the split protocol, not raw generated train/validation/test dataset rows.

## 3. Models and methods
| Model | Architecture | Task adaptation |
|---|---|---|
| Basic Transformer | Encoder–decoder | Train from random initialization |
| mT5-small | Encoder–decoder | Supervised fine-tuning |
| LLaMA 3.2 1B Instruct | Decoder-only | Zero-shot instruction prompting |
| Gemma 3 1B IT | Decoder-only | Zero-shot instruction prompting |

LLaMA/Gemma prompting is used to keep the experiment manageable; their task-specific training time is zero/not applicable because no weights are updated. This is not their pretraining time.

## 4. Compute-conscious settings
- 1,000 examples maximum; 800/100/100 split.
- One epoch for the scratch Transformer and one epoch for mT5.
- Batch size 8; maximum source/target length 64.
- Primary evaluation on the same 100 test examples for all models.
- Temperature evaluation at 0.2, 0.7, and 1.0 on the same 30-example subset for LLaMA and Gemma.

These choices reduce runtime but limit training exposure and generalization. The assignment permits manageable subsets and smaller model variants; if the instructor specifies stricter values, use those.

## 5. Evaluation
- **BLEU:** SacreBLEU corpus score (higher is better).
- **chrF:** character n-gram F-score (higher is better).
- **Training/fine-tuning time:** seconds spent updating task weights.
- **Inference time:** seconds to generate the common test-set translations.
- **Parameters:** sum of model parameter counts.
- **Temperature:** compare 0.2, 0.7, and 1.0 for both prompted models.

## 6. Mock results and analysis
See `artifacts/metrics.csv`, `artifacts/llama_temperature.csv`, `artifacts/gemma_temperature.csv`, and the charts in `artifacts/plots/`. All are synthetic illustrative values. The sample CSVs are demonstration examples, not model-generated outputs. Do not cite them as measured performance.

The illustrative table shows LLaMA with the highest mock BLEU/chrF, followed by Gemma, mT5, and the scratch Transformer. This is only an example of how to interpret a results table. No empirical best-performing model can be concluded until the experiment is run.

## 7. Architecture comparison
Encoder–decoder systems encode the source and condition target generation on the encoded representation, matching the translation task directly. mT5 brings multilingual pretraining; the scratch Transformer must learn translation from the small parallel subset. Decoder-only systems continue from a prompt containing the source and translation instruction; they benefit from general instruction-following pretraining but depend on prompt design and decoding. Differences in tokenization, pretraining, size, and adaptation confound architecture-only conclusions.

## 8. Responsible AI
- **Bias:** inspect gender, dialect, names, demographic terms, and underrepresented cultures; use balanced evaluation slices and fluent reviewers.
- **Hallucination:** detect additions/omissions with source-target adequacy checks, human review, and translation-only prompts.
- **Cultural misrepresentation:** review idioms, humor, honorifics, and culture-specific references with knowledgeable speakers.
- **Sensitive content:** protect private text, validate specialist terminology, use qualified human review for medical/legal/high-impact translation, and do not claim machine output is certified.
- **Governance:** document model/data provenance, disclose machine generation, monitor errors, and provide correction/escalation routes.

## 9. Run the real experiment
Recommended: Colab GPU (T4 or better), Python 3.10/3.11.

```bash
pip install -r requirements.txt
```

Authenticate with Hugging Face after accepting the LLaMA and Gemma model terms:

```python
from huggingface_hub import notebook_login
notebook_login()
```

Then:

```bash
python src/run_experiment.py
```

The script should generate metrics, plots, sample translations, and data splits under `artifacts/`. Replace the mock artifacts only after a successful run. Record hardware and library versions in the final empirical report.

## 10. Repository contents
- `src/`: configuration and experiment script.
- `notebooks/`: Colab/Jupyter notebook.
- `artifacts/`: mock metrics, plots, temperature analysis, sample examples, and disclosure.
- `submission/`: required student-details Word/PDF and a longer mock report in Word/PDF.
- `requirements.txt`: Python dependencies.

## 11. References
- OPUS Books: https://huggingface.co/datasets/Helsinki-NLP/opus_books
- OPUS corpus: https://opus.nlpl.eu/Books
- mT5-small: https://huggingface.co/google/mt5-small
- LLaMA 3.2 1B Instruct: https://huggingface.co/meta-llama/Llama-3.2-1B-Instruct
- Gemma 3 1B IT: https://huggingface.co/google/gemma-3-1b-it
- Transformers translation guide: https://huggingface.co/docs/transformers/tasks/translation
- SacreBLEU: https://github.com/mjpost/sacrebleu


## Evaluation artifact note
The included metric tables, plots, timing values, temperature comparisons, and sample translations are illustrative simulated examples, not measurements from a completed end-to-end run. Run the experiment script to generate empirical results before making performance claims. See `artifacts/RESULTS_README.md`.
