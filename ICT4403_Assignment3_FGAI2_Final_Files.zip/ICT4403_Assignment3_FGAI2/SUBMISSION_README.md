# ICT4403 Assignment 3 submission files

Student: Ravi Sharma  
Registration number: 230953324  
Repository: https://github.com/Sharmaraviii/FGAI2

## Included
- `README.md`: project overview and execution instructions
- `src/`: experiment implementation
- `notebooks/`: notebook
- `artifacts/`: illustrative evaluation outputs and results note
- `results/`: execution guidance
- `submission/`: student details and report documents

## Important evaluation note
The included metrics, timings, plots, temperature comparisons, and example translations are illustrative simulated values. They are not measurements from an executed end-to-end experiment. The report explains this in the evaluation methodology and limitations. Run the code to generate empirical results before claiming measured performance.
