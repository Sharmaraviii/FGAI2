# Upload this project to GitHub from an iPhone

1. Download and save the ZIP to the iPhone Files app.
2. In Files, open Downloads and tap the ZIP once to extract it.
3. Open Safari and sign in to GitHub.
4. Open your repository: https://github.com/Sharmaraviii/FGAI22
5. If it is empty, tap **Add file** → **Upload files**. If needed, use Safari's **aA** menu → **Request Desktop Website**.
6. In the iOS file picker, open the extracted project folder. Select the project files and folders' contents to upload. GitHub's web uploader may require selecting files rather than a whole folder; create the folder paths in GitHub first if needed.
7. Upload the contents of the project (README.md, requirements.txt, src, notebooks, artifacts, results, submission). Do not upload the ZIP as the only repository item.
8. Scroll down, enter commit message `Add ICT4403 Assignment 3 project`, and tap **Commit changes**.
9. Open the repository and check that README.md and the src, notebooks, artifacts, results, and submission folders are visible.

Important: the included metrics, plots, and samples are illustrative simulated examples, not actual model measurements.
