"""Central configuration for the four-model English-to-French translation study."""
SEED = 42
DATASET_ID = "Helsinki-NLP/opus_books"
DATASET_CONFIG = "en-fr"
SOURCE_LANG = "en"
TARGET_LANG = "fr"
MAX_EXAMPLES = 1000          # compact but non-trivial reproducible subset
MAX_SOURCE_LENGTH = 64
MAX_TARGET_LENGTH = 64
TRAIN_FRACTION = 0.80
VALIDATION_FRACTION = 0.10
TEST_FRACTION = 0.10
BATCH_SIZE = 8
EPOCHS = 1
LEARNING_RATE = 5e-5
WEIGHT_DECAY = 0.01
GENERATION_MAX_NEW_TOKENS = 64
TEMPERATURES = [0.2, 0.7, 1.0]
TEMPERATURE_EVAL_SAMPLES = 30
# Small variants are selected to fit a Colab GPU where possible.
MT5_MODEL = "google/mt5-small"
LLAMA_MODEL = "meta-llama/Llama-3.2-1B-Instruct"
GEMMA_MODEL = "google/gemma-3-1b-it"
OUTPUT_DIR = "artifacts"
