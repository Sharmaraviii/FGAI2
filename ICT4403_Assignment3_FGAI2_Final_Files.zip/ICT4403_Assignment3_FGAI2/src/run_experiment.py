"""
ICT4403 Assignment 3: English -> French machine translation comparison.

Run in a GPU-enabled Colab runtime (recommended: T4 or better):
    pip install -r requirements.txt
    huggingface-cli login
    python src/run_experiment.py

LLaMA and Gemma access may require accepting their respective licenses on Hugging Face.
No result values are hard-coded: metrics/timings are measured during execution.
"""
import os, sys, json, time, random, math, argparse
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from datasets import load_dataset
from transformers import (AutoTokenizer, AutoModelForSeq2SeqLM,
                          AutoModelForCausalLM, get_linear_schedule_with_warmup)
from sacrebleu.metrics import BLEU, CHRF
from tqdm.auto import tqdm
import matplotlib.pyplot as plt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import *

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
OUT = Path(OUTPUT_DIR); OUT.mkdir(exist_ok=True, parents=True)
(OUT/"samples").mkdir(exist_ok=True)

def seed_everything(seed=SEED):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def load_splits():
    raw = load_dataset(DATASET_ID, DATASET_CONFIG, split="train")
    rows = []
    for item in raw:
        pair = item["translation"]
        en, fr = pair.get(SOURCE_LANG, "").strip(), pair.get(TARGET_LANG, "").strip()
        if en and fr and len(en) < 600 and len(fr) < 600:
            rows.append({"source": en, "reference": fr})
    rng = np.random.default_rng(SEED); rng.shuffle(rows)
    if MAX_EXAMPLES: rows = rows[:MAX_EXAMPLES]
    n = len(rows); n_train = int(n*TRAIN_FRACTION); n_val = int(n*VALIDATION_FRACTION)
    train = rows[:n_train]; val = rows[n_train:n_train+n_val]; test = rows[n_train+n_val:]
    pd.DataFrame(train).to_csv(OUT/"train.csv", index=False)
    pd.DataFrame(val).to_csv(OUT/"validation.csv", index=False)
    pd.DataFrame(test).to_csv(OUT/"test.csv", index=False)
    print(f"Dataset rows: {n}; train={len(train)}, validation={len(val)}, test={len(test)}")
    return train, val, test

class ParallelDataset(Dataset):
    def __init__(self, rows, tokenizer):
        self.rows, self.tok = rows, tokenizer
    def __len__(self): return len(self.rows)
    def __getitem__(self, i):
        x = self.tok(self.rows[i]["source"], max_length=MAX_SOURCE_LENGTH,
                     truncation=True, padding="max_length", return_tensors="pt")
        y = self.tok(text_target=self.rows[i]["reference"], max_length=MAX_TARGET_LENGTH,
                     truncation=True, padding="max_length", return_tensors="pt")
        labels = y["input_ids"].squeeze(0)
        labels[labels == self.tok.pad_token_id] = -100
        return {"input_ids": x["input_ids"].squeeze(0),
                "attention_mask": x["attention_mask"].squeeze(0), "labels": labels}

def train_seq2seq(model, tokenizer, train, val, name):
    model.to(DEVICE)
    train_loader = DataLoader(ParallelDataset(train, tokenizer), batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(ParallelDataset(val, tokenizer), batch_size=BATCH_SIZE)
    optim = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    total = max(1, len(train_loader)*EPOCHS)
    sched = get_linear_schedule_with_warmup(optim, int(.05*total), total)
    start = time.perf_counter()
    for epoch in range(EPOCHS):
        model.train(); losses=[]
        for batch in tqdm(train_loader, desc=f"{name} epoch {epoch+1}"):
            batch = {k:v.to(DEVICE) for k,v in batch.items()}
            optim.zero_grad(set_to_none=True)
            loss = model(**batch).loss
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optim.step(); sched.step(); losses.append(loss.item())
        model.eval(); vloss=[]
        with torch.no_grad():
            for batch in val_loader:
                batch = {k:v.to(DEVICE) for k,v in batch.items()}
                vloss.append(model(**batch).loss.item())
        print(f"{name}: epoch={epoch+1}, train_loss={np.mean(losses):.4f}, val_loss={np.mean(vloss):.4f}")
    elapsed = time.perf_counter()-start
    model.save_pretrained(OUT/name); tokenizer.save_pretrained(OUT/name)
    return elapsed

def generate_seq2seq(model, tokenizer, texts, temperature=1.0):
    model.eval(); preds=[]; start=time.perf_counter()
    for i in range(0,len(texts),BATCH_SIZE):
        batch = tokenizer(texts[i:i+BATCH_SIZE], return_tensors="pt", padding=True,
                          truncation=True, max_length=MAX_SOURCE_LENGTH).to(DEVICE)
        kwargs = dict(max_new_tokens=GENERATION_MAX_NEW_TOKENS, num_beams=1)
        if temperature != 1.0: kwargs.update(do_sample=True, temperature=max(.05,temperature), top_p=.9)
        else: kwargs.update(do_sample=False)
        with torch.no_grad():
            out=model.generate(**batch, **kwargs)
        preds.extend(tokenizer.batch_decode(out, skip_special_tokens=True))
    elapsed=time.perf_counter()-start
    return preds, elapsed

class TinyTransformer(nn.Module):
    """A compact, train-from-scratch encoder-decoder Transformer."""
    def __init__(self, vocab, pad_id, d_model=128, heads=4, layers=2, ff=256, max_len=128):
        super().__init__(); self.pad_id=pad_id
        self.emb=nn.Embedding(vocab,d_model,padding_idx=pad_id)
        self.pos=nn.Embedding(max_len,d_model)
        self.core=nn.Transformer(d_model=d_model,nhead=heads,
            num_encoder_layers=layers,num_decoder_layers=layers,
            dim_feedforward=ff,dropout=.1,batch_first=True)
        self.out=nn.Linear(d_model,vocab)
    def embed(self,x):
        p=torch.arange(x.size(1),device=x.device).unsqueeze(0)
        return self.emb(x)+self.pos(p)
    def forward(self, src, tgt_in):
        sm=src.eq(self.pad_id); tm=tgt_in.eq(self.pad_id)
        L=tgt_in.size(1); causal=torch.triu(torch.ones(L,L,device=src.device,dtype=torch.bool),1)
        h=self.core(self.embed(src),self.embed(tgt_in),src_key_padding_mask=sm,
                    tgt_key_padding_mask=tm,memory_key_padding_mask=sm,tgt_mask=causal)
        return self.out(h)
    @torch.no_grad()
    def greedy(self, src, bos, eos, max_len):
        self.eval(); out=torch.full((src.size(0),1),bos,device=src.device,dtype=torch.long)
        for _ in range(max_len-1):
            logits=self(src,out)[:,-1,:]; nxt=logits.argmax(-1,keepdim=True)
            out=torch.cat([out,nxt],1)
            if (nxt==eos).all(): break
        return out

def train_basic(train, val):
    tok=AutoTokenizer.from_pretrained("google/mt5-small")
    model=TinyTransformer(len(tok),tok.pad_token_id).to(DEVICE)
    tr=DataLoader(ParallelDataset(train,tok),batch_size=BATCH_SIZE,shuffle=True)
    va=DataLoader(ParallelDataset(val,tok),batch_size=BATCH_SIZE)
    opt=torch.optim.AdamW(model.parameters(),lr=LEARNING_RATE)
    start=time.perf_counter()
    for ep in range(EPOCHS):
        model.train(); losses=[]
        for b in tqdm(tr,desc=f"Basic Transformer epoch {ep+1}"):
            b={k:v.to(DEVICE) for k,v in b.items()}
            labels=b["labels"]; tgt_in=torch.cat([torch.full((labels.size(0),1),tok.pad_token_id,device=DEVICE),labels[:,:-1].clamp_min(0)],1)
            # mT5 tokenizer uses pad as decoder start for this compact baseline.
            opt.zero_grad(set_to_none=True); logits=model(b["input_ids"],tgt_in)
            loss=nn.functional.cross_entropy(logits.reshape(-1,logits.size(-1)),labels.reshape(-1),ignore_index=-100)
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step(); losses.append(loss.item())
        print("Basic Transformer train loss",ep+1,float(np.mean(losses)))
    elapsed=time.perf_counter()-start
    torch.save({"state_dict":model.state_dict(),"config":{"vocab":len(tok),"pad_id":tok.pad_token_id}},OUT/"basic_transformer.pt")
    tok.save_pretrained(OUT/"basic_tokenizer")
    return model,tok,elapsed

def generate_basic(model,tok,texts):
    model.eval(); preds=[]; start=time.perf_counter()
    for i in range(0,len(texts),BATCH_SIZE):
        x=tok(texts[i:i+BATCH_SIZE],return_tensors="pt",padding=True,truncation=True,
              max_length=MAX_SOURCE_LENGTH).to(DEVICE)
        ids=model.greedy(x["input_ids"],tok.pad_token_id,tok.eos_token_id,MAX_TARGET_LENGTH)
        preds.extend(tok.batch_decode(ids,skip_special_tokens=True))
    return preds,time.perf_counter()-start

def load_causal(model_id):
    tok=AutoTokenizer.from_pretrained(model_id, use_fast=True)
    if tok.pad_token is None: tok.pad_token=tok.eos_token
    model=AutoModelForCausalLM.from_pretrained(model_id,torch_dtype=torch.float16 if DEVICE=="cuda" else torch.float32,
        device_map="auto" if DEVICE=="cuda" else None)
    if DEVICE!="cuda": model.to(DEVICE)
    return model,tok

def generate_causal(model,tok,texts,temperature=0.0):
    preds=[]; start=time.perf_counter()
    for s in tqdm(texts,desc="Decoder-only inference"):
        prompt=("Translate the following English text into accurate, natural French. "
                "Return only the French translation.\nEnglish: "+s+"\nFrench:")
        x=tok(prompt,return_tensors="pt",truncation=True,max_length=512).to(model.device)
        kwargs=dict(max_new_tokens=GENERATION_MAX_NEW_TOKENS,pad_token_id=tok.pad_token_id,
                    do_sample=temperature>0)
        if temperature>0: kwargs.update(temperature=temperature,top_p=.9)
        with torch.no_grad(): y=model.generate(**x,**kwargs)
        generated=y[0][x["input_ids"].shape[1]:]
        text=tok.decode(generated,skip_special_tokens=True).strip()
        preds.append(text.split("\n")[0].strip())
    return preds,time.perf_counter()-start

def evaluate(preds, refs):
    return {"BLEU":float(BLEU().corpus_score(preds,[refs]).score),
            "chrF":float(CHRF().corpus_score(preds,[refs]).score)}

def parameter_count(model): return sum(p.numel() for p in model.parameters())

def main():
    seed_everything()
    train,val,test=load_splits()
    sources=[x["source"] for x in test]; refs=[x["reference"] for x in test]
    records=[]; all_outputs={}
    # 1. Basic Transformer trained from scratch.
    basic,tok,bt=train_basic(train,val)
    pred,it=generate_basic(basic,tok,sources); all_outputs["Basic Transformer"]=pred
    records.append({"Model":"Basic Transformer","Architecture":"Encoder-decoder","Parameters":parameter_count(basic),
                    "Train/Fine-tune seconds":bt,"Inference seconds":it,**evaluate(pred,refs)})
    del basic; 
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    # 2. Fine-tuned mT5.
    mtok=AutoTokenizer.from_pretrained(MT5_MODEL)
    mt5=AutoModelForSeq2SeqLM.from_pretrained(MT5_MODEL)
    mt= train_seq2seq(mt5,mtok,train,val,"mt5_finetuned")
    pred,it=generate_seq2seq(mt5,mtok,sources); all_outputs["mT5"]=pred
    records.append({"Model":"mT5-small","Architecture":"Encoder-decoder","Parameters":parameter_count(mt5),
                    "Train/Fine-tune seconds":mt,"Inference seconds":it,**evaluate(pred,refs)})
    del mt5
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    # 3 & 4. Decoder-only models: zero-shot instruction prompting (no weight updates).
    for label,model_id in [("LLaMA",LLAMA_MODEL),("Gemma",GEMMA_MODEL)]:
        model,ctok=load_causal(model_id)
        pred,it=generate_causal(model,ctok,sources,temperature=0.0); all_outputs[label]=pred
        records.append({"Model":model_id,"Architecture":"Decoder-only (prompted)","Parameters":parameter_count(model),
                        "Train/Fine-tune seconds":0.0,"Inference seconds":it,**evaluate(pred,refs)})
        # Sampling temperature experiment on a fixed small subset.
        temp_rows=[]
        for temp in TEMPERATURES:
            p,t=generate_causal(model,ctok,sources[:min(TEMPERATURE_EVAL_SAMPLES,len(sources))],temperature=temp)
            temp_rows.append({"temperature":temp,"BLEU":evaluate(p,refs[:len(p)])["BLEU"],
                              "chrF":evaluate(p,refs[:len(p)])["chrF"],"inference_seconds":t})
        pd.DataFrame(temp_rows).to_csv(OUT/f"{label.lower()}_temperature.csv",index=False)
        del model
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    pd.DataFrame(records).to_csv(OUT/"metrics.csv",index=False)
    for name,preds in all_outputs.items():
        pd.DataFrame({"source":sources,"reference":refs,"translation":preds}).to_csv(
            OUT/"samples"/(name.lower().replace(" ","_")+".csv"),index=False)
    # Plot BLEU and chrF.
    df=pd.DataFrame(records)
    for metric in ["BLEU","chrF"]:
        plt.figure(figsize=(8,4)); plt.bar(df["Model"],df[metric]); plt.ylabel(metric)
        plt.xticks(rotation=20,ha="right"); plt.tight_layout(); plt.savefig(OUT/f"{metric.lower()}_comparison.png",dpi=180); plt.close()
    print(df.to_string(index=False))
    print("Completed. See artifacts/ for metrics, plots, splits and translation samples.")

if __name__=="__main__": main()
